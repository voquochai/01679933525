<?php
	/*
		ĐỊNH NGHĨA CÁC THÔNG TIN TRUY CẬP API
		Chú ý: 
			- Truy cập vào https://daily.pavietnam.vn/loaddata.php?param=api để lấy API KEY
			- Link API test: https://daily.pavietnam.vn/interface_test.php
			- Link API đăng ký thật: https://daily.pavietnam.vn/interface.php
	*/
	define('USERNAME','pavntest');//Username đại lý
	define('API_KEY','e754e2f01cb45826c4022cc0e745940e');//API KEY
	define('API_URL','https://daily.pavietnam.vn/interface_test.php');//Link API (Mặc định đang là link API test)
	
?>